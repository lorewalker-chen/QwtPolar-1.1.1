var searchData=
[
  ['paintattribute',['PaintAttribute',['../class_qwt_polar_canvas.html#a371f88face8daaac6cd556e5f7596613',1,'QwtPolarCanvas::PaintAttribute()'],['../class_qwt_polar_spectrogram.html#a2a6dc68b2e1aa6959b196223bfe2e974',1,'QwtPolarSpectrogram::PaintAttribute()']]]
];
