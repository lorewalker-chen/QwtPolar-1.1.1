var searchData=
[
  ['backingstore',['backingStore',['../class_qwt_polar_canvas.html#a8e40bb677f005bd25c62e65e3e4c8282',1,'QwtPolarCanvas']]],
  ['boundinginterval',['boundingInterval',['../class_qwt_polar_curve.html#ae43e2e9454d340adf4504e3db15cdcd0',1,'QwtPolarCurve::boundingInterval()'],['../class_qwt_polar_item.html#a363ebecfec7301fbc2ed1fd548044cb6',1,'QwtPolarItem::boundingInterval()'],['../class_qwt_polar_marker.html#abf816c0815284945268f24e8f2d8216b',1,'QwtPolarMarker::boundingInterval()'],['../class_qwt_polar_spectrogram.html#a0e1256fa5f44c43bb5d05e125d8bb27b',1,'QwtPolarSpectrogram::boundingInterval()']]]
];
