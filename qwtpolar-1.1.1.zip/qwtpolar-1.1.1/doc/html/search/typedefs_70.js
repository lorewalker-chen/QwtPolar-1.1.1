var searchData=
[
  ['paintattributes',['PaintAttributes',['../class_qwt_polar_canvas.html#ab66cc45b0cc79958d180be66e08c8202',1,'QwtPolarCanvas::PaintAttributes()'],['../class_qwt_polar_spectrogram.html#afc15ef1990ee77db8f96bc8cd760dccd',1,'QwtPolarSpectrogram::PaintAttributes()']]]
];
