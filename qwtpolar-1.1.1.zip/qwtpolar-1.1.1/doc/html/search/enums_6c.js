var searchData=
[
  ['legendattribute',['LegendAttribute',['../class_qwt_polar_curve.html#a48eb3748b6a9b6533386c09fe27f8e89',1,'QwtPolarCurve']]],
  ['legendposition',['LegendPosition',['../class_qwt_polar_plot.html#aeb082672b319273c14f49332d8426d2e',1,'QwtPolarPlot']]]
];
