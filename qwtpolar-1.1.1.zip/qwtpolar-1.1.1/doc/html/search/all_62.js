var searchData=
[
  ['backingstore',['BackingStore',['../class_qwt_polar_canvas.html#a371f88face8daaac6cd556e5f7596613ab8c07aaa7ba2c8833fd4d0cfd9955829',1,'QwtPolarCanvas::BackingStore()'],['../class_qwt_polar_canvas.html#a8e40bb677f005bd25c62e65e3e4c8282',1,'QwtPolarCanvas::backingStore() const ']]],
  ['bottomlegend',['BottomLegend',['../class_qwt_polar_plot.html#aeb082672b319273c14f49332d8426d2ea2385fedbe596ddb9319ca76db6afd9e7',1,'QwtPolarPlot']]],
  ['boundinginterval',['boundingInterval',['../class_qwt_polar_curve.html#ae43e2e9454d340adf4504e3db15cdcd0',1,'QwtPolarCurve::boundingInterval()'],['../class_qwt_polar_item.html#a363ebecfec7301fbc2ed1fd548044cb6',1,'QwtPolarItem::boundingInterval()'],['../class_qwt_polar_marker.html#abf816c0815284945268f24e8f2d8216b',1,'QwtPolarMarker::boundingInterval()'],['../class_qwt_polar_spectrogram.html#a0e1256fa5f44c43bb5d05e125d8bb27b',1,'QwtPolarSpectrogram::boundingInterval()']]]
];
