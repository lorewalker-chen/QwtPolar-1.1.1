var searchData=
[
  ['externallegend',['ExternalLegend',['../class_qwt_polar_plot.html#aeb082672b319273c14f49332d8426d2ea90bc392c0e385337fa017280e9b8c410',1,'QwtPolarPlot']]]
];
